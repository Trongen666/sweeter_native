# sweetener_recommender.py
import streamlit as st
from agent import full_sweetener_analysis

st.title("🍭 Sugar Substitute Recommender")

st.markdown("Enter a recipe and user context. We'll analyze it and recommend the most scientifically suitable sweetener alternative.")

# --- Inputs ---
recipe = st.text_area("Recipe or Ingredient List", "Spicy curry with tomatoes, onions, and coconut milk")
user_profile = st.text_area("User Profile (health, taste, preferences)", "Diabetic, low-calorie preference")
sweetener = st.text_input("Default Sweetener to Replace", "Processed Sugar")

if st.button("Find Best Alternative"):
    with st.spinner("Analyzing and generating sweetener recommendation..."):
        recommendation, sources = full_sweetener_analysis(
            recipe=recipe,
            user_profile=user_profile,
            sweetener=sweetener
        )

    st.subheader("🧠 AI Recommendation")
    st.markdown(recommendation)

    if sources:
        st.subheader("🛒 Where to Buy")
        for src in sources:
            st.markdown(f"- [{src['name']}]({src['url']})")
    else:
        st.info("No buying sources found automatically. Try searching manually.")