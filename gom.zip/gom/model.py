
import torch
import torch.nn as nn
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem

class SensoryCNN(nn.Module):
    def __init__(self):
        super(SensoryCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 16, 3, padding=1)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(16, 32, 3, padding=1)
        self.fc1 = nn.Linear(32 * 8 * 8, 64)
        self.fc2 = nn.Linear(64, 1)

    def forward(self, x):
        x = self.pool(nn.ReLU()(self.conv1(x)))
        x = self.pool(nn.ReLU()(self.conv2(x)))
        x = x.view(-1, 32 * 8 * 8)
        x = nn.ReLU()(self.fc1(x))
        return self.fc2(x)

def _smiles_to_ecfp_tensor(smiles: str) -> torch.Tensor:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError("Invalid SMILES")

    fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=1024)
    arr = np.zeros((1024,), dtype=np.float32)
    AllChem.DataStructs.ConvertToNumpyArray(fp, arr)
    ecfp = arr.reshape(1, 32, 32)
    return torch.tensor(ecfp, dtype=torch.float32).unsqueeze(0)

def predict_sweetness(smiles: str, model: nn.Module) -> float:
    try:
        x = _smiles_to_ecfp_tensor(smiles)
        model.eval()
        with torch.no_grad():
            prediction = model(x).item()
        return round(prediction, 2)
    except Exception as e:
        raise ValueError(f"Error predicting sweetness: {e}")

def predict_aftertaste(smiles: str, model: nn.Module) -> float:
    try:
        x = _smiles_to_ecfp_tensor(smiles)
        model.eval()
        with torch.no_grad():
            prediction = model(x).item()
        return round(prediction, 2)
    except Exception as e:
        raise ValueError(f"Error predicting aftertaste: {e}")
