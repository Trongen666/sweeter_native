

from langchain_community.llms import HuggingFaceHub
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage
from model import predict_sweetness, predict_aftertaste
from utils import get_smiles, get_sweetener_components
from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

# Get your HF token and model
hf_api_key = os.getenv("HUGGINGFACEHUB_API_TOKEN")
hf_model_name = os.getenv("HF_CHAT_MODEL", "mistralai/Mistral-7B-Instruct-v0.1")

if not hf_api_key:
    raise ValueError("HUGGINGFACEHUB_API_TOKEN not found in .env")

class SweetenerAdvisorAgent:
    def __init__(self):
        self.MASTER_PROMPT = """
You are a food scientist AI that recommends the best sugar substitutes based on:

- Recipe and ingredient context
- User profile or health conditions
- Taste and chemical interactions
- Scientific insights like sweetness index, aftertaste, and natural composition

Instructions:
1. Analyze the given recipe and extract ingredients if needed.
2. Determine if processed sugar should be replaced based on health context or dietary needs.
3. Use the provided sweetness index and aftertaste scores to evaluate candidate sweeteners.
4. Consider molecular interactions and flavor balance to assess clashes or synergies.
5. Recommend the best natural sweetener or a combination to replicate sugar's effects.
6. Justify your recommendation with scientific reasoning.
7. Mention any notable health or taste benefits relevant to the user's profile.
8. Finally, suggest where the recommended sweetener(s) can be bought online (e.g., Amazon, iHerb).
"""
        self.llm = HuggingFaceHub(
            repo_id=hf_model_name,
            model_kwargs={"temperature": 0.7, "max_new_tokens": 512},
            huggingfacehub_api_token=hf_api_key,
        )

    def get_predictions(self, sweetener: str):
        components = get_sweetener_components(sweetener)
        all_targets = [sweetener] + components

        sweetness_scores = {}
        aftertaste_scores = {}

        for compound in all_targets:
            smiles = get_smiles(compound)
            if not smiles:
                continue
            sweetness_scores[compound] = predict_sweetness(smiles)
            aftertaste_scores[compound] = predict_aftertaste(smiles)

        return components, sweetness_scores, aftertaste_scores

    def extract_ingredients(self, recipe_text):
        return [i.strip() for i in recipe_text.split(",") if i.strip()]

    def full_sweetener_analysis(self, recipe, user_profile, sweetener="Processed Sugar"):
        ingredients = self.extract_ingredients(recipe)
        components, sweetness_scores, aftertaste_scores = self.get_predictions(sweetener)

        content = f"""
User Profile: {user_profile}
Recipe: {recipe}
Extracted Ingredients: {ingredients}

Sweetener to replace: {sweetener}
Components: {components}

Sweetness Indices: {sweetness_scores}
Aftertaste Scores: {aftertaste_scores}
"""

        agent = self._create_agent()
        result = agent.invoke({"messages": [HumanMessage(content=content)]})
        response_msg = result.content if hasattr(result, "content") else str(result)

        return response_msg

    def _create_agent(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", self.MASTER_PROMPT),
            MessagesPlaceholder(variable_name="messages")
        ])
        return prompt | self.llm

# Public function
sweetener_agent = SweetenerAdvisorAgent()

def full_sweetener_analysis(recipe, user_profile, sweetener="Processed Sugar"):
    return sweetener_agent.full_sweetener_analysis(recipe, user_profile, sweetener)

