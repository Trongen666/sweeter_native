# cnn_train.py
import torch
from torch.utils.data import Dataset, DataLoader
from model import SensoryCNN
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem

# ---- Step 1: Dataset class ----
class ECfpDataset(Dataset):
    def __init__(self, df, n_bits=1024):
        self.smiles = df["SMILES"]
        self.labels = df["AftertasteScore"].values
        self.n_bits = n_bits

    def __len__(self):
        return len(self.smiles)

    def __getitem__(self, idx):
        s = self.smiles.iloc[idx]
        mol = Chem.MolFromSmiles(s)
        fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=self.n_bits)
        arr = np.zeros((self.n_bits,), dtype=np.float32)
        AllChem.DataStructs.ConvertToNumpyArray(fp, arr)
        img = arr.reshape(1, 32, 32)
        label = self.labels[idx]
        return torch.tensor(img), torch.tensor(label)

# ---- Step 2: Load data ----
df = pd.read_csv("data/flavor.csv")  # has 'SMILES', 'AftertasteScore'
dataset = ECfpDataset(df)
loader = DataLoader(dataset, batch_size=16, shuffle=True)

# ---- Step 3: Train ----
model = SensoryCNN()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
loss_fn = torch.nn.MSELoss()

for epoch in range(500):
    for x, y in loader:
        pred = model(x)
        loss = loss_fn(pred.squeeze(), y.float())
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    print(f"Epoch {epoch+1}, Loss: {loss.item():.4f}")

# ---- Step 4: Save model ----
torch.save(model.state_dict(), "cnn_model.pth")
print("Saved cnn_model.pth ✅")
