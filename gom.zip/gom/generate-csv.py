

import csv
import pubchempy as pcp
from rdkit import Chem
from rdkit.Chem import AllChem, DataStructs
import numpy as np
import torch
from model import SensoryCNN

# --- List of 50 sugar molecules and sweeteners ---
molecule_list = [
    "Coconut sugar", "Date sugar", "Pomegranate molasses", "Stevia", "Aspartame", "Sucralose",
    "Saccharin", "Acesulfame potassium", "Xylitol", "Erythritol", "Maltitol", "Sorbitol",
    "Agave syrup", "Honey", "Maple syrup", "Brown sugar", "Molasses", "Turbinado sugar",
    "Yacon syrup", "Allulose", "Isomalt", "Lactitol", "Monk fruit", "Neotame", "Thaumatin",
    "Cyclamate", "Glycyrrhizin", "Tagatose", "Palatinose", "Fructose", "Glucose",
    "Sucrose", "Lactose", "Trehalose", "Mannitol", "Panela", "Demerara sugar", "Barley malt syrup",
    "Birch syrup", "Corn syrup", "Invert sugar", "Golden syrup", "Rock sugar", "Raw honey",
    "Cane sugar", "Beet sugar", "Coconut nectar", "Rice syrup", "Fruit juice concentrate", "Carob syrup"
]

# --- Fallback data for failed PubChem lookups ---
user_fallback_data = {
    "Coconut sugar": {
        "Molecular Formula": "C12H22O11",
        "Molecular Weight": 342.30,
        "Canonical SMILES": "C(C1C(C(C(C(O1)O)O)O)O)O",
        "XLogP": -3.7,
        "HBond Donor Count": 8,
        "Topological Polar Surface Area": 180.15,
        "Complexity": 378.0,
        "SweetnessIndex": 6
    },
    "Date sugar": {
        "Molecular Formula": "C6H12O6",
        "Molecular Weight": 180.16,
        "Canonical SMILES": "C(C1C(C(C(C(O1)O)O)O)O)O",
        "XLogP": -3.2,
        "HBond Donor Count": 5,
        "Topological Polar Surface Area": 110.38,
        "Complexity": 120.0,
        "SweetnessIndex": 8
    },
    "Pomegranate molasses": {
        "Molecular Formula": "C7H6O3",
        "Molecular Weight": 138.12,
        "Canonical SMILES": "C1=CC(=CC=C1C(=O)O)O",
        "XLogP": 0.7,
        "HBond Donor Count": 3,
        "Topological Polar Surface Area": 77.76,
        "Complexity": 125.0,
        "SweetnessIndex": 3
    },

    "Stevia": {
        "Molecular Formula": "C38H60O18",
        "Molecular Weight": 804.88,
        "Canonical SMILES": "CC1(C)CCC2(C(C1)CCC3(C2CCC4(C3(CC(C4O)CO)O)C)C)C",
        "XLogP": -1.7,
        "HBond Donor Count": 8,
        "Topological Polar Surface Area": 200.0,
        "Complexity": 1300.0,
        "SweetnessIndex": 250
    },
    "Aspartame": {
        "Molecular Formula": "C14H18N2O5",
        "Molecular Weight": 294.30,
        "Canonical SMILES": "CC(CC(=O)O)NC(=O)C(Cc1ccccc1)N",
        "XLogP": -1.5,
        "HBond Donor Count": 3,
        "Topological Polar Surface Area": 100.5,
        "Complexity": 340.0,
        "SweetnessIndex": 200
    },
    "Sucralose": {
        "Molecular Formula": "C12H19Cl3O8",
        "Molecular Weight": 397.64,
        "Canonical SMILES": "C(C1C(C(C(C(O1)O)Cl)O)Cl)OC(C(C(CO)O)O)Cl",
        "XLogP": -2.0,
        "HBond Donor Count": 6,
        "Topological Polar Surface Area": 150.0,
        "Complexity": 650.0,
        "SweetnessIndex": 600
    },
    "Saccharin": {
        "Molecular Formula": "C7H5NO3S",
        "Molecular Weight": 183.18,
        "Canonical SMILES": "C1=CC=C2C(=C1)C(=NS2(=O)=O)O",
        "XLogP": -0.7,
        "HBond Donor Count": 1,
        "Topological Polar Surface Area": 83.6,
        "Complexity": 250.0,
        "SweetnessIndex": 300
    },
    "Acesulfame potassium": {
        "Molecular Formula": "C4H4KNO4S",
        "Molecular Weight": 201.23,
        "Canonical SMILES": "CC1=CC(=O)NS(=O)(=O)O1.[K+]",
        "XLogP": -2.0,
        "HBond Donor Count": 1,
        "Topological Polar Surface Area": 96.6,
        "Complexity": 270.0,
        "SweetnessIndex": 200
    },
    "Xylitol": {
        "Molecular Formula": "C5H12O5",
        "Molecular Weight": 152.15,
        "Canonical SMILES": "C(C(C(C(CO)O)O)O)O",
        "XLogP": -2.2,
        "HBond Donor Count": 5,
        "Topological Polar Surface Area": 100.0,
        "Complexity": 90.0,
        "SweetnessIndex": 1
    },
    "Erythritol": {
        "Molecular Formula": "C4H10O4",
        "Molecular Weight": 122.12,
        "Canonical SMILES": "C(C(CO)O)O",
        "XLogP": -2.0,
        "HBond Donor Count": 4,
        "Topological Polar Surface Area": 80.0,
        "Complexity": 75.0,
        "SweetnessIndex": 0.7
    },
    "Maltitol": {
        "Molecular Formula": "C12H24O11",
        "Molecular Weight": 344.31,
        "Canonical SMILES": "C(C1C(C(C(C(O1)CO)O)O)O)OC(C(C(CO)O)O)CO",
        "XLogP": -3.5,
        "HBond Donor Count": 7,
        "Topological Polar Surface Area": 180.0,
        "Complexity": 400.0,
        "SweetnessIndex": 0.9
    },
    "Sorbitol": {
        "Molecular Formula": "C6H14O6",
        "Molecular Weight": 182.17,
        "Canonical SMILES": "C(C(C(C(C(CO)O)O)O)O)O",
        "XLogP": -2.6,
        "HBond Donor Count": 6,
        "Topological Polar Surface Area": 110.0,
        "Complexity": 120.0,
        "SweetnessIndex": 0.6
    },
    "Allulose": {
        "Molecular Formula": "C6H12O6",
        "Molecular Weight": 180.16,
        "Canonical SMILES": "C(C1C(C(C(C(O1)O)O)O)O)O",
        "XLogP": -3.0,
        "HBond Donor Count": 5,
        "Topological Polar Surface Area": 110.38,
        "Complexity": 120.0,
        "SweetnessIndex": 0.7
    },
    "Isomalt": {
        "Molecular Formula": "C12H24O11",
        "Molecular Weight": 344.31,
        "Canonical SMILES": "C(C1C(C(C(C(O1)CO)O)O)O)OC(C(C(CO)O)O)CO",
        "XLogP": -3.4,
        "HBond Donor Count": 6,
        "Topological Polar Surface Area": 180.0,
        "Complexity": 390.0,
        "SweetnessIndex": 0.5
    },
    "Lactitol": {
        "Molecular Formula": "C12H24O11",
        "Molecular Weight": 344.31,
        "Canonical SMILES": "C(C1C(C(C(C(O1)CO)O)O)O)OC(C(C(CO)O)O)CO",
        "XLogP": -3.3,
        "HBond Donor Count": 7,
        "Topological Polar Surface Area": 180.0,
        "Complexity": 410.0,
        "SweetnessIndex": 0.35
    },
    "Neotame": {
    "Molecular Formula": "C20H30N2O5",
    "Molecular Weight": 378.47,
    "Canonical SMILES": "CC(C)(C)CC(C(=O)N[C@@H](CC1=CC=CC=C1)C(=O)O)NC(=O)OC",
    "XLogP": 1.7,
    "HBond Donor Count": 2,
    "Topological Polar Surface Area": 127.0,
    "Complexity": 574.0,
    "SweetnessIndex": 8000
},

"Cyclamate": {
    "Molecular Formula": "C6H13NO3S",
    "Molecular Weight": 179.24,
    "Canonical SMILES": "C1CCNCC1S(=O)(=O)O",
    "XLogP": -1.2,
    "HBond Donor Count": 1,
    "Topological Polar Surface Area": 58.3,
    "Complexity": 172.0,
    "SweetnessIndex": 26
},

"Thaumatin": {
    "Molecular Formula": "C22H32O17",
    "Molecular Weight": 552.48,
    "Canonical SMILES": "C(C1C(C(C(C(O1)O)O)O)O)OC2C(C(C(C(O2)CO)O)O)O",
    "XLogP": -5.0,
    "HBond Donor Count": 11,
    "Topological Polar Surface Area": 231.0,
    "Complexity": 438.0,
    "SweetnessIndex": 2000
},

"Glycyrrhizin": {
    "Molecular Formula": "C42H62O16",
    "Molecular Weight": 822.93,
    "Canonical SMILES": "C[C@H]1[C@H]2[C@H]3[C@@H]([C@H](C[C@@]4([C@H]3CC[C@@]5([C@@H]4CC[C@]5(C)C)C)C)C(=O)O)O[C@H]2[C@@H]([C@H]1O)O[C@@H]6[C@@H]([C@H]([C@@H]([C@H](O6)CO)O)O)O",
    "XLogP": -1.0,
    "HBond Donor Count": 8,
    "Topological Polar Surface Area": 206.0,
    "Complexity": 1070.0,
    "SweetnessIndex": 30
},

"Alitame": {
    "Molecular Formula": "C14H25N3O4S",
    "Molecular Weight": 331.43,
    "Canonical SMILES": "CC(C)CC(C(=O)NCCSC(=O)N[C@@H](CCC(=O)O)C(=O)O)N",
    "XLogP": -1.1,
    "HBond Donor Count": 4,
    "Topological Polar Surface Area": 148.0,
    "Complexity": 523.0,
    "SweetnessIndex": 2000
}

}

# --- Chemical data retrieval ---
def get_chemical_data(name):
    try:
        compound = pcp.get_compounds(name, 'name')[0]
        return {
            'Molecular Weight': compound.molecular_weight,
            'Canonical SMILES': compound.canonical_smiles,
            'XLogP': compound.xlogp,
            'HBond Donor Count': compound.h_bond_donor_count,
            'Topological Polar Surface Area': compound.tpsa,
            'Complexity': compound.complexity
        }
    except Exception:
        return user_fallback_data.get(name)

# --- ECFP Fingerprint ---
def smiles_to_ecfp(smiles, n_bits=1024):
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        return None
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=n_bits)
    arr = np.zeros((n_bits,), dtype=np.float32)
    DataStructs.ConvertToNumpyArray(fp, arr)
    return arr.reshape(1, 1, 32, 32)

# --- CNN Aftertaste prediction ---
def predict_aftertaste(smiles, model_path="cnn_model.pth"):
    ecfp = smiles_to_ecfp(smiles)
    if ecfp is None:
        return None
    x = torch.tensor(ecfp, dtype=torch.float32)
    model = SensoryCNN()
    model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    model.eval()
    with torch.no_grad():
        return round(model(x).item(), 2)

# --- CSV Generation ---
def generate_csvs(sweetness_path="data/sweetness.csv", flavor_path="data/flavor.csv"):
    sweetness_fields = ["Name", "Molecular Weight", "XLogP", "HBond Donor Count", "Topological Polar Surface Area", "Complexity", "SweetnessIndex"]
    flavor_fields = ["Name", "SMILES", "AftertasteScore"]

    with open(sweetness_path, "w", newline='') as sfile, open(flavor_path, "w", newline='') as ffile:
        sweetness_writer = csv.DictWriter(sfile, fieldnames=sweetness_fields)
        flavor_writer = csv.DictWriter(ffile, fieldnames=flavor_fields)

        sweetness_writer.writeheader()
        flavor_writer.writeheader()

        for name in molecule_list:
            data = get_chemical_data(name)

            if not data or not data.get("Canonical SMILES"):
                print(f"❌ Skipped (no data): {name}")
                continue

            # If SweetnessIndex is missing, skip
            sweetness_index = user_fallback_data.get(name, {}).get("SweetnessIndex")
            if sweetness_index is None:
                print(f"❌ Skipped (no SweetnessIndex): {name}")
                continue

            # Write to sweetness.csv
            sweetness_writer.writerow({
                "Name": name,
                "Molecular Weight": data["Molecular Weight"],
                "XLogP": data["XLogP"],
                "HBond Donor Count": data["HBond Donor Count"],
                "Topological Polar Surface Area": data["Topological Polar Surface Area"],
                "Complexity": data["Complexity"],
                "SweetnessIndex": sweetness_index
            })

            # Predict and write to flavor.csv
            aftertaste_score = predict_aftertaste(data["Canonical SMILES"])
            flavor_writer.writerow({
                "Name": name,
                "SMILES": data["Canonical SMILES"],
                "AftertasteScore": aftertaste_score if aftertaste_score is not None else "NA"
            })

# --- Run ---
if __name__ == "__main__":
    generate_csvs()
    print("✅ Generated sweetness.csv and flavor.csv with 50 sweeteners.")

