

import streamlit as st
from utils import get_chemical_data, smiles_to_ecfp, predict_aftertaste
import pandas as pd
import numpy as np
import joblib
import os

# Load sweetness model
@st.cache_resource
def load_sweetness_model(path="sweetness_model.pkl"):
    return joblib.load(path)

sweetness_model = load_sweetness_model()

# Page title
st.title("🍬 Sweetener Predictor App")
st.markdown("Predict sweetness and aftertaste of natural and synthetic sweeteners.")

# Sidebar input
input_mode = st.sidebar.radio("Input Mode", ["Sweetener Name", "SMILES"])

if input_mode == "Sweetener Name":
    user_input = st.text_input("Enter sweetener name (e.g., 'Stevia', 'Coconut sugar')", "")
else:
    user_input = st.text_input("Enter SMILES (e.g., 'C(C1C(C(C(C(O1)O)O)O)O)O')", "")

if st.button("🔍 Predict"):
    if not user_input.strip():
        st.warning("Please enter a valid input.")
    else:
        # Get data
        if input_mode == "Sweetener Name":
            chem_data = get_chemical_data(user_input)
            if not chem_data:
                st.error("No data found for this sweetener.")
                st.stop()
            smiles = chem_data["Canonical SMILES"]
        else:
            chem_data = None
            smiles = user_input.strip()

        # Predict aftertaste
        aftertaste_score = predict_aftertaste(smiles)

        # Prepare sweetness prediction
        ecfp = smiles_to_ecfp(smiles)
        if ecfp is None:
            st.error("Invalid SMILES. Cannot process.")
            st.stop()

        try:
            # Get the expected number of features for the model
            expected_features = sweetness_model.n_features_in_
            
            # Since the model expects 5 features but we have 1024,
            # we need to extract meaningful features from our fingerprint
            
            # Option 1: Use dimensionality reduction (simple approach)
            # Extract 5 features by:
            # - sum of all bits
            # - count of 1s
            # - variance of the fingerprint
            # - two highest bit values or indices
            
            flattened_ecfp = ecfp.flatten()
            feature1 = np.sum(flattened_ecfp)  # Sum of all bits
            feature2 = np.count_nonzero(flattened_ecfp)  # Count of non-zero bits
            feature3 = np.var(flattened_ecfp)  # Variance
            
            # Get the two highest values in the fingerprint
            sorted_idx = np.argsort(flattened_ecfp)
            feature4 = flattened_ecfp[sorted_idx[-1]] if len(sorted_idx) > 0 else 0  # Highest value
            feature5 = flattened_ecfp[sorted_idx[-2]] if len(sorted_idx) > 1 else 0  # Second highest value
            
            # Create feature array with exactly 5 features
            X = np.array([[feature1, feature2, feature3, feature4, feature5]])
            
            # Display the extracted features for debugging
            st.write(f"Debug - Extracted features: {X}")
            
            # Make prediction
            sweetness_score = sweetness_model.predict(X)[0]
            
        except Exception as e:
            st.error(f"Sweetness prediction failed: {str(e)}")
            st.stop()

        # Display results
        st.subheader("🧪 Results")
        st.metric("Sweetness Index", round(sweetness_score, 2))
        st.metric("Aftertaste Score", aftertaste_score)

        # Show chemical info
        if chem_data:
            st.subheader("🔬 Molecular Data")
            chem_df = pd.DataFrame.from_dict(chem_data, orient="index", columns=["Value"])
            st.dataframe(chem_df)

# Footer
st.markdown("---")
st.markdown("Developed by [Your Name] using RDKit, PubChem, and PyTorch 💡")