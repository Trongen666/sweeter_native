import csv
import numpy as np
import torch
import pubchempy as pcp
from rdkit import Chem
from rdkit.Chem import AllChem
from model import SensoryCNN

# --- User fallback data if PubChem doesn't return info ---
user_fallback_data = {
    "Coconut sugar": {
        "Molecular Formula": "C12H22O11",
        "Molecular Weight": 342.30,
        "Canonical SMILES": "C(C1C(C(C(C(O1)O)O)O)O)O",  # same as sucrose
        "Isomeric SMILES": None,
        "IUPAC Name": "β-D-fructofuranosyl α-D-glucopyranoside",
        "InChI": "InChI=1S/C12H22O11/c13-1-3-6(16)8(18)9(19)10(21-3)23-12(22)11(20)7(17)5(15)2-14/h3,5-11,13-20H,1-2H2/t3-,5+,6+,7+,8+,9-,10+,11-,12-/m1/s1",
        "InChI Key": "CZNMNGXOGPZSDW-ZXZARUISSA-N",
        "XLogP": -3.7,
        "Charge": 0,
        "HBond Donor Count": 8,
        "HBond Acceptor Count": 11,
        "Rotatable Bond Count": 4,
        "Exact Mass": 342.1162,
        "Topological Polar Surface Area": 180.15,
        "Complexity": 378.0,
        "Synonyms": ["Coconut palm sugar", "Coconut blossom sugar"]
    },
    "Date sugar": {
        "Molecular Formula": "C6H12O6",
        "Molecular Weight": 180.16,
        "Canonical SMILES": "C(C1C(C(C(C(O1)O)O)O)O)O",  # similar to glucose
        "Isomeric SMILES": None,
        "IUPAC Name": "D-glucose",
        "InChI": "InChI=1S/C6H12O6/c7-1-2-3(8)5(10)6(11)12-4(2)9/h2-11H,1H2",
        "InChI Key": "WQZGKKKJIJFFOK-GASJEMHNSA-N",
        "XLogP": -3.2,
        "Charge": 0,
        "HBond Donor Count": 5,
        "HBond Acceptor Count": 6,
        "Rotatable Bond Count": 2,
        "Exact Mass": 180.0634,
        "Topological Polar Surface Area": 110.38,
        "Complexity": 120.0,
        "Synonyms": ["Date fruit sugar", "Phoenix dactylifera sugar"]
    },
    "Pomegranate molasses": {
        "Molecular Formula": "C7H6O3",
        "Molecular Weight": 138.12,
        "Canonical SMILES": "C1=CC(=CC=C1C(=O)O)O",  # using gallic acid as proxy
        "Isomeric SMILES": None,
        "IUPAC Name": "3,4,5-trihydroxybenzoic acid",
        "InChI": "InChI=1S/C7H6O5/c8-4-1-3(2-5(9)6(4)10)7(11)12/h1-2,8-10H,(H,11,12)",
        "InChI Key": "LNTHITQXZRNRMG-UHFFFAOYSA-N",
        "XLogP": 0.7,
        "Charge": 0,
        "HBond Donor Count": 3,
        "HBond Acceptor Count": 4,
        "Rotatable Bond Count": 1,
        "Exact Mass": 138.0317,
        "Topological Polar Surface Area": 77.76,
        "Complexity": 125.0,
        "Synonyms": ["Punica granatum syrup", "Molasses of pomegranate"]
    }
}

# --- Function to get chemical data from PubChem ---
def get_chemical_data(name):
    print(f"Fetching chemical data for {name}...")
    try:
        compound = pcp.get_compounds(name, 'name')[0]
        print(f"Successfully retrieved data for {name} from PubChem.")
        return {
            'Molecular Formula': compound.molecular_formula,
            'Molecular Weight': compound.molecular_weight,
            'Canonical SMILES': compound.canonical_smiles,
            'Isomeric SMILES': compound.isomeric_smiles,
            'IUPAC Name': compound.iupac_name,
            'InChI': compound.inchi,
            'InChI Key': compound.inchikey,
            'XLogP': compound.xlogp,
            'Charge': compound.charge,
            'HBond Donor Count': compound.h_bond_donor_count,
            'HBond Acceptor Count': compound.h_bond_acceptor_count,
            'Rotatable Bond Count': compound.rotatable_bond_count,
            'Exact Mass': compound.exact_mass,
            'Topological Polar Surface Area': compound.tpsa,
            'Complexity': compound.complexity,
            'Synonyms': compound.synonyms[:5] if compound.synonyms else None
        }
    except (IndexError, Exception) as e:
        print(f"Error fetching data for {name}: {e}")
        return user_fallback_data.get(name, None)

# --- Function to convert SMILES to ECFP (Extended Connectivity Fingerprints) ---
def smiles_to_ecfp(smiles, n_bits=1024):
    print(f"Converting SMILES to ECFP: {smiles}")
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        print(f"Invalid SMILES: {smiles}")
        return None
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=n_bits)
    arr = np.zeros((n_bits,), dtype=np.float32)
    AllChem.DataStructs.ConvertToNumpyArray(fp, arr)
    print(f"ECFP generated for {smiles}")
    return arr.reshape(1, 32, 32)

# --- Function to predict aftertaste using CNN model ---
def predict_aftertaste(smiles, model_path="cnn_model.pth"):
    print(f"Predicting aftertaste for SMILES: {smiles}")
    ecfp = smiles_to_ecfp(smiles)
    if ecfp is None:
        print("Invalid SMILES, unable to predict aftertaste.")
        return "Invalid SMILES"
    x = torch.tensor(ecfp, dtype=torch.float32).unsqueeze(0)
    model = SensoryCNN()
    print(f"Loading model from {model_path}")
    model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    model.eval()
    with torch.no_grad():
        prediction = model(x).item()
    print(f"Prediction completed: {prediction}")
    return round(prediction, 2)

# --- Function to generate and save the dataset to CSV ---
def generate_dataset_csv(output_file="sweetener_dataset.csv"):
    print(f"Generating dataset and saving to {output_file}...")
    fieldnames = ['Name', 'SMILES', 'Aftertaste'] + [f'ECFP_{i}' for i in range(1024)]
    
    with open(output_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(fieldnames)
        
        for name, chem_data in user_fallback_data.items():
            smiles = chem_data.get("Canonical SMILES")
            print(f"Processing {name}...")
            ecfp = smiles_to_ecfp(smiles)
            if ecfp is None:
                print(f"Skipping {name} due to invalid SMILES")
                continue

            aftertaste = predict_aftertaste(smiles)  # Or use your own label
            
            flat_ecfp = ecfp.flatten().tolist()
            row = [name, smiles, aftertaste] + flat_ecfp
            writer.writerow(row)

    print(f"✅ Dataset saved to: {output_file}")


# --- Function to get the SMILES string for a compound ---
def get_smiles(compound: str) -> str:
    """
    Retrieve the canonical SMILES for a compound using PubChem or fallback data.
    """
    data = get_chemical_data(compound)
    if data and data.get("Canonical SMILES"):
        return data["Canonical SMILES"]
    else:
        print(f"No SMILES found for: {compound}")
        return None


# --- Function to break down a compound name into components ---
def get_sweetener_components(sweetener: str) -> list:
    """
    Splits multi-component sweetener names into individual sweeteners.
    For example: "Stevia + Erythritol" -> ["Stevia", "Erythritol"]
    """
    delimiters = ["+", "/", "&", ",", " and ", " with "]
    for delimiter in delimiters:
        if delimiter in sweetener:
            return [s.strip() for s in sweetener.split(delimiter) if s.strip()]
    return []  # return empty if it's a single-component sweetener

