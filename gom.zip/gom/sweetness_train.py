import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import joblib

# Load data
df = pd.read_csv("data/sweetness.csv")

# Drop non-numeric column
X = df.drop(columns=["Name", "SweetnessIndex"])  # features
y = df["SweetnessIndex"]  # target

# Train model
model = RandomForestRegressor()
model.fit(X, y)

# Save model
joblib.dump(model, "sweetness_model.pkl")
print("✅ Trained and saved sweetness_model.pkl")
